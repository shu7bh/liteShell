#ifndef __COLORS_H
#define __COLORS_H

void green();
void blue();
void red();
void yellow();
void magenta();
void reset();
void cPrompt();

#endif

