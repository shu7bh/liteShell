#ifndef PINFO_H
#define PINFO_H

void pinfo(int, char**);

#endif
