#ifndef MAKECHILD_H
#define MAKECHILD_H

void makeChildFg(char* argv[3]);
void makeChildBg(char* argv[3]);

#endif
