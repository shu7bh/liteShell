#ifndef CWD_H
#define CWD_H

const char* getCWD();

#endif
