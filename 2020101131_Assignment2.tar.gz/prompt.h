#ifndef __PROMPT_H
#define __PROMPT_H

void setPromptVar();
void prompt();

#endif
