#ifndef HOMEDIR_H
#define HOMEDIR_H

void setHomeDirVar();
const char* getHomeDir();

#endif
