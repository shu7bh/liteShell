#ifndef CD_H
#define CD_H

int cd(char* argv);

#endif
