#ifndef CALLWRITTENFUNCTIONS_H
#define CALLWRITTENFUNCTIONS_H

int callWrittenFunctions(char **argv, int argc);

#endif
