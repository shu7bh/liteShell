#ifndef STRINGTONUM_H
#define STRINGTONUM_H

int stringToNum(char*);

#endif
