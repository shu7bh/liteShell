#ifndef RUN_COMMAND_H
#define RUN_COMMAND_H

void runCommand();

#endif
