#ifndef TOKEN_H
#define TOKEN_H

//void setTokenVar();
int tokenize(char*, char**, int*, int*);

#endif
