#ifndef ECHO_H
#define ECHO_H

void echo(int, char**);

#endif
