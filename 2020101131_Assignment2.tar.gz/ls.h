#ifndef LS_H
#define LS_H

int ls(int, char**);

#endif
