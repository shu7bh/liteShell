#ifndef PROCESSTERMINATION_H
#define PROCESSTERMINATION_H

void handleProcessTermination(int sig);

#endif
